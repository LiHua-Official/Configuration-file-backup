#include"base.h"
#include"com/mesonbuild/subbie.h"

int main(int argc, char **argv) {
    return base() + subbie();
}
