int a_fun() {
    return 1;
}
