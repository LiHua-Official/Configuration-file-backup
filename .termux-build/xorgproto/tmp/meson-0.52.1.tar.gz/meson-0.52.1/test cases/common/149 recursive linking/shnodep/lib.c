#include "../lib.h"

SYMBOL_EXPORT
int get_shnodep_value (void) {
  return 1;
}
