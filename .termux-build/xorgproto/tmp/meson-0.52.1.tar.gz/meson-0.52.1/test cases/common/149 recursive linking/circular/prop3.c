int get_st3_prop (void) {
  return 3;
}
