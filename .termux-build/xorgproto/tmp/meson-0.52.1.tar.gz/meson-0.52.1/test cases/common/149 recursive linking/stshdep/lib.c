#include "../lib.h"

int get_shnodep_value (void);

SYMBOL_EXPORT
int get_stshdep_value (void) {
  return get_shnodep_value ();
}
