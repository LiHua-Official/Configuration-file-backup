int get_cval (void) {
  return 0;
}
