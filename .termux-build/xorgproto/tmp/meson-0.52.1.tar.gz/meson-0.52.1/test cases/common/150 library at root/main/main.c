extern int fn(void);

int main() {
    return 1 + fn();
}
