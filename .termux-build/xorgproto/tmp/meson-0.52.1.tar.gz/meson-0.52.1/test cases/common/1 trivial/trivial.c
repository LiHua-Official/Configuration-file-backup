#include<stdio.h>

int main(int argc, char **argv) {
    printf("Trivial test is working.\n");
    return 0;
}
