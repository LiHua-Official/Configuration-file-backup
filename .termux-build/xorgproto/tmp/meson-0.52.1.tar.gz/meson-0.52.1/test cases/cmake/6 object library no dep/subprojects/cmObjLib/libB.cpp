#include "libB.hpp"

std::string getZlibVers() {
  return "STUB";
}
